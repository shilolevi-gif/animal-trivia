package com.example.myapplication66;

import android.Manifest;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import android.widget.Switch;
import android.widget.Toast;


import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import java.util.Calendar;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {
    private String selectedDifficulty = "easy"; // ברירת מחדל
    private final String[] difficultyLevels = {"easy", "medium", "hard"};
    String url;
    private ActivityResultLauncher<Intent> playLauncher;
    private int brightnessLevel = 0;
    private SharedPreferences sharedPreferences;
    private static final String PREFS_NAME = "app_settings";
    private static final String BRIGHTNESS_KEY = "brightness_level";

    private static final String PREFS_NAME2 = "app_settings";
    private static final String DIFFICULTY_KEY = "difficulty";

    Button btnMenu;
    MediaPlayer mainMusic;
    Switch switchReminder;






    @Override
    protected void onCreate(Bundle savedInstanceState)
    {



        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main_xml), (v, insets) ->
        {
            if (mainMusic == null) {
                mainMusic = MediaPlayer.create(this, R.raw.cloud);
                mainMusic.setLooping(true);
                mainMusic.start();
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                requestPermissions(
                        new String[]{Manifest.permission.POST_NOTIFICATIONS},
                        101
                );
            }

            switchReminder = findViewById(R.id.Reminder);
            switchReminder.setChecked(isReminderEnabled());

            switchReminder.setOnCheckedChangeListener((buttonView, isChecked) -> {

                if (isChecked) {
                    scheduleDailyNotification();
                    saveReminderState(true);
                } else {
                    cancelDailyNotification();
                    saveReminderState(false);
                }
            });






            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;





        });
        sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        brightnessLevel = sharedPreferences.getInt(BRIGHTNESS_KEY, 0);

        applyBrightness(brightnessLevel);
        createNotificationChannel();
        scheduleDailyNotification();

        sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        selectedDifficulty = sharedPreferences.getString(DIFFICULTY_KEY, difficultyLevels[1]);





        btnMenu = findViewById(R.id.btn_menu);

        Button btnSettings = findViewById(R.id.difficulty);
        btnSettings.setOnClickListener(v -> showDifficultyDialog());
        Button stats = findViewById(R.id.Stats);
        ImageButton Play = findViewById(R.id.btn_Play);
        playLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK) {
                        Intent data = result.getData();
                        if (data != null && data.getBooleanExtra("open_stats", false)) {
                            FragmentManager fm = getSupportFragmentManager();
                            fm.beginTransaction()
                                    .replace(R.id.fragmentContainerView, new StatsFragment(), "StatsFragmentTag")
                                    .addToBackStack("StatsFragmentTag")
                                    .commit();
                        }
                    }
                }
        );


        btnMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                PopupMenu popupMenu = new PopupMenu(MainActivity.this, btnMenu);
                popupMenu.getMenuInflater().inflate(R.menu.menu_popup, popupMenu.getMenu());

                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(@NonNull MenuItem item) {

                        if (item.getItemId() == R.id.menu_volume) {

                            AudioManager audioManager =
                                    (AudioManager) getSystemService(AUDIO_SERVICE);

                            audioManager.adjustVolume(
                                    AudioManager.ADJUST_SAME,
                                    AudioManager.FLAG_SHOW_UI
                            );
                            return true;

                        } else if (item.getItemId() == R.id.menu_logout) {


                            finish();
                            return true;
                        }
                        else if (item.getItemId() == R.id.menu_brightness) {

                            brightnessLevel = (brightnessLevel + 1) % 3;

                            SharedPreferences.Editor editor = sharedPreferences.edit();
                            editor.putInt(BRIGHTNESS_KEY, brightnessLevel);
                            editor.apply();

                            applyBrightness(brightnessLevel);

                            float brightness;
                            String text;

                            switch (brightnessLevel) {
                                case 0:
                                    brightness = 0.3f;
                                    text = "low brightness";
                                    break;
                                case 1:
                                    brightness = 0.6f;
                                    text = "medium brightness";
                                    break;
                                default:
                                    brightness = 1.0f;
                                    text = "high brightness";
                                    break;
                            }

                            WindowManager.LayoutParams params = getWindow().getAttributes();
                            params.screenBrightness = brightness;
                            getWindow().setAttributes(params);

                            Toast.makeText(MainActivity.this, text, Toast.LENGTH_SHORT).show();

                            return true;
                        }


                        return false;
                    }
                });

                popupMenu.show();
            }
        });



        stats.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)

            {

                FragmentManager fm = getSupportFragmentManager();
                Fragment existingFragment = fm.findFragmentByTag("StatsFragmentTag");

                if (existingFragment != null && existingFragment.isVisible()) {
                    fm.popBackStack();
                } else {

                    fm.beginTransaction()
                            .replace(R.id.fragmentContainerView, new StatsFragment(), "StatsFragmentTag")
                            .setReorderingAllowed(true)
                            .addToBackStack("StatsFragmentTag")
                            .commit();
                }
            }
        });

        Play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Bundle bundle = new Bundle();
                bundle.putString("difficulty", selectedDifficulty);
                Intent intent = new Intent(MainActivity.this, PlayActivity.class);
                intent.putExtras(bundle);
                playLauncher.launch(intent);
            }
        });





    }
    @Override
    protected void onPause() {
        super.onPause();
        if (mainMusic != null && mainMusic.isPlaying()) {
            mainMusic.pause();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mainMusic != null && !mainMusic.isPlaying()) {
            mainMusic.start();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mainMusic != null) {
            mainMusic.stop();
            mainMusic.release();
            mainMusic = null;
        }
    }


    public void showPlayButton(boolean show) {
        ImageButton play = findViewById(R.id.btn_Play);
        play.setVisibility(show ? View.VISIBLE : View.GONE);
    }
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

            NotificationChannel channel =
                    new NotificationChannel(
                            "QUIZ_CHANNEL",
                            "Quiz Notifications",
                            NotificationManager.IMPORTANCE_DEFAULT
                    );

            NotificationManager manager =
                    getSystemService(NotificationManager.class);

            manager.createNotificationChannel(channel);
        }
    }
    private void scheduleDailyNotification() {

        Intent intent = new Intent(this, DailyNotificationReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                this,
                0,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);

        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, 16);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);

        //  קבע למחר
        if (calendar.getTimeInMillis() < System.currentTimeMillis()) {
            calendar.add(Calendar.DAY_OF_MONTH, 1);
        }

        alarmManager.setRepeating(
                AlarmManager.RTC_WAKEUP,
                calendar.getTimeInMillis(),
                AlarmManager.INTERVAL_DAY,
                pendingIntent
        );
    }
    private void cancelDailyNotification() {

        Intent intent = new Intent(this, DailyNotificationReceiver.class);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                this,
                0,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
        alarmManager.cancel(pendingIntent);
    }
    private void saveReminderState(boolean enabled) {
        SharedPreferences prefs = getSharedPreferences("settings", MODE_PRIVATE);
        prefs.edit().putBoolean("daily_reminder", enabled).apply();
    }

    private boolean isReminderEnabled() {
        SharedPreferences prefs = getSharedPreferences("settings", MODE_PRIVATE);
        return prefs.getBoolean("daily_reminder", false);
    }

    private void applyBrightness(int level)
    {
        float brightness;
        switch (level) {
            case 0: brightness = 0.3f; break;
            case 1: brightness = 0.6f; break;
            default: brightness = 1.0f; break;
        }

        WindowManager.LayoutParams params = getWindow().getAttributes();
        params.screenBrightness = brightness;
        getWindow().setAttributes(params);
    }


    private void showDifficultyDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Select Difficulty");

        int checkedItem = getCheckedItemIndex(); // האופציה כרגע

        builder.setSingleChoiceItems(difficultyLevels, checkedItem, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                selectedDifficulty = difficultyLevels[which];
            }
        });

        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {


                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString(DIFFICULTY_KEY, selectedDifficulty);
                editor.apply();

                Bundle bundle = new Bundle();
                bundle.putString("difficulty", selectedDifficulty);
                Intent intent = new Intent(MainActivity.this, PlayActivity.class);
                intent.putExtras(bundle);
                playLauncher.launch(intent);


            }
        });
        builder.setNegativeButton("Cancel", null);
        builder.show();



    }
    private int getCheckedItemIndex() {
        for (int i = 0; i < difficultyLevels.length; i++) {
            if (difficultyLevels[i].equals(selectedDifficulty)) {
                return i;
            }
        }
        return 1;
    }


}

