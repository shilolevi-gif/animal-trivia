package com.example.myapplication66;

public class TopPlayer {
    public String uid;
    public String email;

    public int score;




    public TopPlayer(String uid, String email, int score) {
        this.uid = uid;
        this.email = email;
        this.score = score;
    }
}
