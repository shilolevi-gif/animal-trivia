package com.example.myapplication66;

import android.text.Html;

public class HtmlUtils {
    public static String decodeHtml(String html) {
        if (html == null) return "";

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            return Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY).toString();
        } else {
            return Html.fromHtml(html).toString();
        }
    }
}
