
package com.example.myapplication66;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class RegisterActivity extends AppCompatActivity {

    private FirebaseAuth auth;
    private EditText Remail, Rpass;
    private Button Regbutton;
    private TextView Already;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_register);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.register_xml), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;



        });



        auth = FirebaseAuth.getInstance();
            Remail = findViewById(R.id.Remail);
            Rpass = findViewById(R.id.Rpass);
            Regbutton = findViewById(R.id.Regbutton);
            Already = findViewById(R.id.Already);
            Regbutton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String email = Remail.getText().toString().trim();
                    String pass = Rpass.getText().toString().trim();

                    if(!email.isEmpty() && Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                        if(!pass.isEmpty()){
                            auth.createUserWithEmailAndPassword(email, pass)
                                    .addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                                        @Override
                                        public void onSuccess(AuthResult authResult) {
                                            Toast.makeText(RegisterActivity.this, "sign in successful", Toast.LENGTH_SHORT).show();
                                            startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
                                            finish();
                                        }
                                    }).addOnFailureListener(new OnFailureListener() {
                                        @Override
                                        public void onFailure(@NonNull Exception e) {
                                            Toast.makeText(RegisterActivity.this, "sign in failed", Toast.LENGTH_SHORT).show();

                                        }
                                    });


                        } else {
                            Rpass.setError("password cannot be empty");
                        }
                    } else if (email.isEmpty()) {
                        Remail.setError("email cannot be empty");
                    } else {
                        Remail.setError("enter valid email");

                    }
                }

            });
            Already.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    startActivity(new Intent(RegisterActivity.this, LoginActivity.class));

                }
            });





    }
}