package com.example.myapplication66;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class QuestionFetcher {

    private OkHttpClient client = new OkHttpClient();

    public interface QuestionFetchListener {
        void onQuestionsFetched(List<Question> questions);
        void onError(String error);
    }

    //  מקבל רמת קושי כפרמטר
    public void fetchQuestions(String difficulty, QuestionFetchListener listener) {

        int amount = 15;
        String url = "https://opentdb.com/api.php?amount=" + amount +
                "&category=27" +
                "&difficulty=" + difficulty +
                "&type=multiple";


        Log.d("TRIVIA_FETCH", "Fetching: " + url);

        Request request = new Request.Builder().url(url).build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.e("TRIVIA_ERROR", "Network failure", e);
                new android.os.Handler(Looper.getMainLooper()).post(() ->
                        listener.onError("שגיאת רשת: " + e.getMessage())
                );
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                try {
                    String body = response.body().string();
                    Log.d("TRIVIA_FETCH", "Response (" + difficulty + "): " + body);

                    JSONObject json = new JSONObject(body);
                    int code = json.getInt("response_code");

                    if (code != 0) {

                        new android.os.Handler(Looper.getMainLooper()).post(() ->
                                listener.onError("Not enough questions were found at the level '" + difficulty + "' code: " + code)
                        );
                        return;
                    }

                    JSONArray results = json.getJSONArray("results");
                    List<Question> questions = new ArrayList<>();

                    for (int i = 0; i < results.length(); i++) {
                        JSONObject obj = results.getJSONObject(i);
                        String questionText = HtmlUtils.decodeHtml(obj.getString("question"));
                        String correct = HtmlUtils.decodeHtml(obj.getString("correct_answer"));
                        JSONArray incorrectArr = obj.getJSONArray("incorrect_answers");

                        List<String> options = new ArrayList<>();
                        options.add(correct);
                        for (int j = 0; j < incorrectArr.length(); j++) {
                            options.add(HtmlUtils.decodeHtml(incorrectArr.getString(j)));
                        }

                        Collections.shuffle(options);
                        int correctIndex = options.indexOf(correct);

                        // המערך options בגודל 4
                        if (options.size() != 4) {
                            Log.w("TRIVIA_FETCH", "Unexpected options count: " + options.size());
                            continue;
                        }

                        questions.add(new Question(
                                questionText,
                                options.toArray(new String[0]),
                                correctIndex,
                                difficulty
                        ));
                    }

                    new android.os.Handler(Looper.getMainLooper()).post(() ->
                            listener.onQuestionsFetched(questions)
                    );

                } catch (Exception e) {
                    Log.e("TRIVIA_ERROR", "Parsing failed", e);
                    new android.os.Handler(Looper.getMainLooper()).post(() ->
                            listener.onError("שגיאת עיבוד: " + e.getMessage())
                    );
                }
            }
        });
    }
}
