package com.example.myapplication66;

import java.util.ArrayList;
import java.util.List;

public class QuestionBank {
        public static List<Question> getQuestions() {
            List<Question> questions = new ArrayList<>();
            //22

            questions.add(new Question(
                    "Which animal is the largest in the world?",
                    new String[]{"Elephant", "Blue whale", "Giraffe", "Rhino"},
                    1,
                    "easy"
            ));

            questions.add(new Question(
                    "Which animal can imitate human sounds and say words?",
                    new String[]{"Gerbil", "African grey parrot", "Cuckoo", "Owl"},
                    1,
                    "easy"
            ));

            questions.add(new Question(
                    "Which animal is the fastest on land?",
                    new String[]{"Lion", "Horse", "Cheetah", "Zebra"},
                    2,
                    "easy"
            ));

            questions.add(new Question(
                    "Which animal lays eggs?",
                    new String[]{"Dog", "Cat", "Cow", "Duck"},
                    3,
                    "easy"
            ));

            questions.add(new Question(
                    "Which animal is commonly used for food?",
                    new String[]{"Tiger", "Cow", "Giraffe", "Bear"},
                    1,
                    "easy"
            ));

            questions.add(new Question(
                    "Which animal lives in the North Pole?",
                    new String[]{"Penguin", "Polar bear", "Rhino", "Monkey"},
                    1,
                    "easy"
            ));

            questions.add(new Question(
                    "Which animal uses its large ears to cool down?",
                    new String[]{"Elephant", "Fox", "Rabbit", "Horse"},
                    0,
                    "easy"
            ));

            questions.add(new Question(
                    "Which animal is considered very social and a popular pet?",
                    new String[]{"Dog", "Crocodile", "Field rat", "Scorpion"},
                    0,
                    "easy"
            ));

            questions.add(new Question(
                    "Which animal lays the largest eggs?",
                    new String[]{"Crocodile", "Duck", "Penguin", "Ostrich"},
                    3,
                    "easy"
            ));

            questions.add(new Question(
                    "Which animal is known for its powerful roar?",
                    new String[]{"Lion", "Tiger", "Monkey", "Wolf"},
                    0,
                    "easy"
            ));

            questions.add(new Question(
                    "Which animal lives in the desert and can go days without water?",
                    new String[]{"Horse", "Camel", "Goat", "Sheep"},
                    1,
                    "easy"
            ));

            questions.add(new Question(
                    "Which animal uses its long nose to eat?",
                    new String[]{"Horse", "Elephant", "Bear", "Deer"},
                    1,
                    "easy"
            ));

            questions.add(new Question(
                    "Which animal flies but does not chirp?",
                    new String[]{"Bat", "Eagle", "Mouse", "Dolphin"},
                    0,
                    "easy"
            ));

            questions.add(new Question(
                    "Which animal likes to eat bananas?",
                    new String[]{"Lion", "Monkey", "Tiger", "Wolf"},
                    1,
                    "easy"
            ));

            questions.add(new Question(
                    "Which animal is known for its high jumps?",
                    new String[]{"Falcon", "Monkey", "Deer", "Lion"},
                    2,
                    "easy"
            ));

            questions.add(new Question(
                    "Which animal lives in a nest it builds by itself?",
                    new String[]{"Bear", "Bird", "Moose", "Snake"},
                    1,
                    "easy"
            ));

            questions.add(new Question(
                    "Which animal uses its tail to balance while climbing trees?",
                    new String[]{"Cat", "Monkey", "Fox", "Ostrich"},
                    1,
                    "easy"
            ));

            questions.add(new Question(
                    "Which animal can live both in water and on land?",
                    new String[]{"Fish", "Frog", "Horse", "Bat"},
                    1,
                    "easy"
            ));

            questions.add(new Question(
                    "Which animal was considered sacred in ancient Egypt?",
                    new String[]{"Cat", "Rhinoceros", "Cockroach", "Sheep"},
                    0,
                    "easy"
            ));

            questions.add(new Question(
                    "Which bird has a long and deep beak?",
                    new String[]{"Rooster", "Pigeon", "Eagle", "Pelican"},
                    3,
                    "easy"
            ));

            questions.add(new Question(
                    "Which animal beats its chest to show dominance?",
                    new String[]{"Mouse", "Monkey", "Lizard", "Gorilla"},
                    3,
                    "easy"
            ));

            questions.add(new Question(
                    "Which animal has the longest neck?",
                    new String[]{"Snake", "Crocodile", "Deer", "Giraffe"},
                    3,
                    "easy"
            ));



            // הוסף עד 15 שאלות לפי רמות קושי

            return questions;
        }



}
