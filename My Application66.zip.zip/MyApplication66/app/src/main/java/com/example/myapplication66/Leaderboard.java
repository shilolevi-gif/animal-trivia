package com.example.myapplication66;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Leaderboard extends AppCompatActivity {
    DatabaseReference ref;

    TextView player1,player2,player3,player4,player5;
    FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_leaderboard);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        player1=findViewById(R.id.top1);
        player2=findViewById(R.id.top2);
        player3=findViewById(R.id.top3);
        player4=findViewById(R.id.top4);
        player5=findViewById(R.id.top5);

        Button exit = findViewById(R.id.exit);

        exit.setOnClickListener(v -> {
            finish();
        });


        DatabaseReference ref = FirebaseDatabase.getInstance()
                .getReference("top5");

        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                if (snapshot.child("1").exists()) {
                    Integer score = snapshot.child("1").child("score").getValue(Integer.class);
                    String email = snapshot.child("1").child("email").getValue(String.class);

                    player1.setText("the score-   " + score + " points🥇" +  "\nthe player -   " + email);
                }

                if (snapshot.child("2").exists()) {
                    Integer score = snapshot.child("2").child("score").getValue(Integer.class);
                    String email = snapshot.child("2").child("email").getValue(String.class);

                    player2.setText("the score-   " + score + " points🥈" +  "\nthe player -   " + email);
                }

                if (snapshot.child("3").exists()) {
                    Integer score = snapshot.child("3").child("score").getValue(Integer.class);
                    String email = snapshot.child("3").child("email").getValue(String.class);

                    player3.setText("the score-   " + score + " points🥉" +  "\nthe player -   " + email);
                }

                if (snapshot.child("4").exists()) {
                    Integer score = snapshot.child("4").child("score").getValue(Integer.class);
                    String email = snapshot.child("4").child("email").getValue(String.class);

                    player4.setText("the score-   " + score + " points🏅" +  "\nthe player -   " + email);
                }

                if (snapshot.child("5").exists()) {
                    Integer score = snapshot.child("5").child("score").getValue(Integer.class);
                    String email = snapshot.child("5").child("email").getValue(String.class);

                    player5.setText("the score-   " + score + " points👍" +  "\nthe player -   " + email);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });



    }
}
