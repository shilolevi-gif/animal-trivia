package com.example.myapplication66;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.myapplication66.databinding.ActivityMainBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class PlayActivity extends AppCompatActivity {
    private List<Question> questions ;
    private int currentQuestionIndex = 0, c=0;
    private int score = 0;

    private long START_TIME_IN_MILLIS = 5 * 60 * 1000;
    TextView timerTextView, QN;
    CountDownTimer countDownTimer;

     TextView scoreTextView;
     Button answer1,answer2,answer3,answer4;
    TextView question;
    MediaPlayer playMusic, correctSound, wrongSound;
    ActivityMainBinding binding;
    FirebaseDatabase db;
    DatabaseReference reference;
    FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();






        @Override
    protected void onCreate(Bundle savedInstanceState)
    {

        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_play);
        Intent intent = getIntent();
        Bundle extras = intent.getExtras();
        String difficulty = extras.getString("difficulty", "medium");




        playMusic = MediaPlayer.create(this, R.raw.hopper);
        playMusic.setLooping(true);
        playMusic.start();

        correctSound = MediaPlayer.create(this, R.raw.correct_sound);
        wrongSound = MediaPlayer.create(this, R.raw.wrong_sound);

        scoreTextView = findViewById(R.id.Score);
        answer1 = findViewById(R.id.option1);
        answer2 = findViewById(R.id.option2);
        answer3 = findViewById(R.id.option3);
        answer4 = findViewById(R.id.option4);
        question = findViewById(R.id.Question);
        QN = findViewById(R.id.QuestionNumber);

        timerTextView = findViewById(R.id.Time);
        if (difficulty.equals("easy")) {

            // שאלות מקומיות
            questions = QuestionBank.getQuestions();

            Collections.shuffle(questions);

            currentQuestionIndex = 0;
            c = 0;
            score = 0;
            scoreTextView.setText("0");

            showNextQuestion(difficulty);
            startTimer();

        } else {

            QuestionFetcher fetcher = new QuestionFetcher();

            fetcher.fetchQuestions(difficulty, new QuestionFetcher.QuestionFetchListener() {
                @Override
                public void onQuestionsFetched(List<Question> fetchedQuestions) {
                    if (fetchedQuestions == null || fetchedQuestions.isEmpty()) {
                        Toast.makeText(PlayActivity.this, "No questions found at this difficulty level " + difficulty, Toast.LENGTH_LONG).show();
                        finish();
                        return;
                    }

                    // אם  יותר מ-15
                    questions = new ArrayList<>();
                    int limit = Math.min(15, fetchedQuestions.size());
                    for (int i = 0; i < limit; i++) {
                        questions.add(fetchedQuestions.get(i));
                    }

                    Collections.shuffle(questions);

                    currentQuestionIndex = 0;
                    c = 0;
                    score = 0;
                    scoreTextView.setText("0");
                    showNextQuestion(difficulty);
                }

                @Override
                public void onError(String error) {
                    Log.e("TRIVIA_ERROR", error);
                    Toast.makeText(PlayActivity.this, "loading failed: " + error, Toast.LENGTH_LONG).show();
                    finish();
                }
            });
            startTimer();
        }








        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.play_xml), (v, insets) ->
        {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;


        });





    }
    public void answerCorrect() {
        correctSound.start();
    }

    public void answerWrong() {
        wrongSound.start();
    }
    @Override
    protected void onPause() {
        super.onPause();
        if(playMusic != null) playMusic.pause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if(playMusic != null) playMusic.start();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(playMusic != null) playMusic.release();
        if(correctSound != null) correctSound.release();
        if(wrongSound != null) wrongSound.release();
    }

    private void saveStatsToFirebase() {
        Toast.makeText(this, "------ Save Stats To Firebase --------", Toast.LENGTH_LONG).show();
        String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("users").child(uid);

        long timeLeftSeconds = START_TIME_IN_MILLIS / 1000;

        // עדכון lastScore ו-lastTime תמיד
        reference.child("lastScore").setValue(score);
        Toast.makeText(this, "------ Last com.example.myapplication66.Score uploaded --------", Toast.LENGTH_LONG).show();

        reference.child("lastTime").setValue(timeLeftSeconds);
        Toast.makeText(this, "------ Last Time uploaded --------", Toast.LENGTH_LONG).show();


        // עדכון highScore
        reference.child("highScore").get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Integer oldHigh = task.getResult().getValue(Integer.class);
                int newHigh = Math.max(score, oldHigh != null ? oldHigh : 0);
                reference.child("highScore").setValue(newHigh);
            } else {
                //
                reference.child("highScore").setValue(score);
            }
        });
    }


    private void updateGlobalTopScore(int newScore) {

        String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
        DatabaseReference top5Ref =
                FirebaseDatabase.getInstance().getReference("top5");

        top5Ref.get().addOnSuccessListener(snapshot -> {

            List<TopPlayer> list = new ArrayList<>();


            for (DataSnapshot snap : snapshot.getChildren()) {
                TopPlayer p = snap.getValue(TopPlayer.class);
                if (p != null) {
                    list.add(p);
                }
            }

            // בדיקה אם המשתמש כבר קיים
            boolean found = false;
            for (TopPlayer p : list) {
                if (p.uid.equals(uid)) {
                    found = true;

                    if (newScore > p.score) {
                        p.score = newScore;
                    }
                    break;
                }
            }

            // אם לא קיים
            if (!found) {
                list.add(new TopPlayer(uid, user.getEmail(), newScore));
            }

            //  מהגבוה לנמוך
            Collections.sort(list, (a, b) -> b.score - a.score);


            if (list.size() > 5) {
                list = list.subList(0, 5);
            }

            // כתיבה מחדש
            top5Ref.removeValue();
            for (int i = 0; i < list.size(); i++) {
                top5Ref.child(String.valueOf(i + 1)).setValue(list.get(i));
            }
        });
    }








    private void saveStats() {
        long timeLeftSeconds = START_TIME_IN_MILLIS / 1000;

        // SharedPreferences
        getSharedPreferences("game_stats", MODE_PRIVATE)
                .edit()
                .putInt("last_score", score)
                .putLong("last_time", timeLeftSeconds)
                .putInt("high_score", Math.max(
                        score,
                        getSharedPreferences("game_stats", MODE_PRIVATE)
                                .getInt("high_score", 0)
                ))
                .apply();
    }




    private void startTimer()
    {
        countDownTimer = new CountDownTimer(START_TIME_IN_MILLIS, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                START_TIME_IN_MILLIS = millisUntilFinished;
                int minutes = (int) (START_TIME_IN_MILLIS / 1000) / 60;
                int seconds = (int) (START_TIME_IN_MILLIS / 1000) % 60;

                String timeFormatted = String.format("%02d:%02d", minutes, seconds);
                timerTextView.setText(timeFormatted);
            }

            @Override
            public void onFinish() {
                timerTextView.setText("Time over");
                Intent resultIntent = new Intent();
                resultIntent.putExtra("open_stats", true);
                setResult(RESULT_OK, resultIntent);
                finish();
            }
        }.start();
    }

    private void showNextQuestion(String difficulty) {

        if (c >= 15 || currentQuestionIndex >= questions.size()) {
            Toast.makeText(this, "Game over! ✅\n your score: " + score, Toast.LENGTH_LONG).show();


            saveStatsToFirebase();
            updateGlobalTopScore(score);
            saveStats();



            Intent resultIntent = new Intent();
            resultIntent.putExtra("open_stats", true);
            setResult(RESULT_OK, resultIntent);
            finish();

            return;
        }

        Question currentQ = questions.get(currentQuestionIndex);
        question.setText(currentQ.getQuestionText());
        QN.setText(String.valueOf(currentQuestionIndex + 1)+"/15");

        String[] opts = currentQ.getOptions();
        answer1.setText(opts[0]);
        answer2.setText(opts[1]);
        answer3.setText(opts[2]);
        answer4.setText(opts[3]);

        setOptionClickListeners(currentQ.getCorrectAnswerIndex(), difficulty);
    }




    private void setOptionClickListeners(int correctAnswerIndex, String difficulty) {
        View.OnClickListener listener = v -> {
            int clickedIndex = -1;
            if (v == answer1) clickedIndex = 0;
            else if (v == answer2) clickedIndex = 1;
            else if (v == answer3) clickedIndex = 2;
            else if (v == answer4) clickedIndex = 3;

            boolean isCorrect = (clickedIndex == correctAnswerIndex);

            if (isCorrect) {
                score += 20;
                Toast.makeText(PlayActivity.this, "True! 🎉 +20", Toast.LENGTH_SHORT).show();
                answerCorrect();
            } else {
                Toast.makeText(PlayActivity.this, "Wrong 😅", Toast.LENGTH_SHORT).show();
                answerWrong();
            }

            scoreTextView.setText(String.valueOf(score));


            currentQuestionIndex++;
            c++;
            showNextQuestion(difficulty);
        };

        answer1.setOnClickListener(listener);
        answer2.setOnClickListener(listener);
        answer3.setOnClickListener(listener);
        answer4.setOnClickListener(listener);

    }
}

